// Ignite CLI plugin for VzIrBoilerplate
// ----------------------------------------------------------------------------

const NPM_MODULE_NAME = 'react-native-MODULENAME'
const NPM_MODULE_VERSION = '0.0.1'

// const PLUGIN_PATH = __dirname
// const APP_PATH = process.cwd()


const add = async function (context) {}

/**
 * Remove yourself from the project.
 */
const remove = async function (context) {}

// Required in all Ignite CLI plugins
module.exports = { add, remove }

