# My Plugin

This is where you would put an intro to your plugin, and maybe a few examples of usage. 

## Example

```js
console.log("Hello World")
```

