const test = require('ava')
const plugin = require('../plugin')

test('has the right interface', async t => {
  t.is(typeof plugin.add, 'function')
  t.is(typeof plugin.remove, 'function')
})
